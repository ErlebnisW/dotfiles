---
description: Search for recent papers on a topic without full analysis
argument-hint: "[topic] [--days N] [--source arxiv|scholar|all]"
allowed-tools: Task, WebSearch, WebFetch, Read, Write
---

# Search Papers

Search for recent papers on a given topic and return a simple list without deep analysis.

## Topic

$ARGUMENTS

## Argument Parsing

- **topic** (required): The research topic or query string
- **--days N** (default: 7): Time window in days
- **--source arxiv|scholar|all** (default: all): Restrict to a specific source

## Workflow

### Step 1: Search

Deploy parallel searches based on the `--source` flag:

**If source = arxiv or all:**
```
WebSearch: site:arxiv.org [topic] [current year]
```

**If source = scholar or all:**
```
WebSearch: [topic] research paper [current year]
WebSearch: site:semanticscholar.org [topic]
```

**If source = all (additionally):**
```
WebSearch: site:paperswithcode.com [topic]
WebSearch: site:huggingface.co/papers [topic]
```

### Step 2: Collect Metadata

For each paper found, use WebFetch on the paper URL to collect:
- **Title**
- **Authors** (first author + et al. if many)
- **Date** (publication or submission date)
- **Abstract** (first 2-3 sentences)
- **Source URL**
- **Citation count** (if available from Semantic Scholar)

### Step 3: Filter and Deduplicate

- Remove papers outside the time window
- Deduplicate by arXiv ID or title similarity (>90% match)
- Sort by date (newest first)

### Step 4: Output

Present results as a numbered markdown list:

```markdown
## Recent Papers: [topic] (last N days)

Found X papers. Searched: [sources used].

### 1. [Paper Title]
**Authors:** First Author et al.
**Date:** YYYY-MM-DD
**Abstract:** First 2-3 sentences of abstract...
**Link:** https://arxiv.org/abs/XXXX.XXXXX
**Citations:** N (if available)

---

### 2. [Paper Title]
...
```

If no papers are found, report that clearly and suggest:
- Expanding the time window
- Broadening the search terms
- Trying different sources

Output the results directly to the user (not saved to file unless they request it).
