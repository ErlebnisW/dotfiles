---
description: Deep-analyze a single paper given its URL or title
argument-hint: "[paper URL or title]"
allowed-tools: Task, WebSearch, WebFetch, Read, Write
---

# Analyze Paper

Perform a deep analysis of a single academic paper.

## Paper

$ARGUMENTS

## Workflow

### Step 1: Locate the Paper

**If a URL is provided** (contains arxiv.org, semanticscholar.org, openreview.net, etc.):
- Use WebFetch to retrieve the paper's abstract page
- Extract title, authors, abstract, date, venue

**If a title is provided:**
- Use WebSearch to find the paper: `"[exact title]" arxiv OR semanticscholar`
- Use WebFetch on the best matching result to get metadata

### Step 2: Gather Context

- Fetch the full abstract and introduction if accessible
- Search for related blog posts or summaries: `[paper title] summary OR explained OR review`
- Check for code implementations: `site:github.com [paper title]` or `site:paperswithcode.com [paper title]`
- Look for citation context on Semantic Scholar if available

### Step 3: Deep Analysis

Apply the **paper-analyzer** sub-skill framework to produce:

#### Must-Read Rationale
Why should a PhD researcher read this paper? What will they gain that they cannot get elsewhere? Be specific and compelling.

#### Core Insight
The central idea or contribution in 2-3 sentences. What is the key "aha" moment? What does this paper understand that previous work missed?

#### Technical Approach
- **Problem formulation**: What exact problem are they solving? What are the inputs and outputs?
- **Proposed method/architecture**: How does the solution work at a high level?
- **Key innovations vs prior work**: What is genuinely new here? What is the delta over existing methods?

#### Hardest Problem & Solution
What was the most challenging technical problem the authors faced? How did they solve it? This section is often the most valuable for researchers because it reveals non-obvious engineering and theoretical insights.

#### Key Results
- Main quantitative results with specific numbers
- How results compare to state-of-the-art
- Most important ablation findings
- Any surprising results or counter-intuitive findings

#### Limitations & Open Questions
- What the paper explicitly acknowledges as limitations
- What the paper does NOT solve but should
- Open questions for future work
- Potential failure modes or edge cases

#### Connections
- What prior work this builds upon (direct lineage)
- What concurrent/subsequent work relates to this
- What research directions this enables

#### One-Line Summary
A single tweet-length sentence capturing the essence of the paper.

### Step 4: Output

Present the analysis directly to the user in a well-formatted markdown structure.

If the user wants to save it, write to `RESEARCH/paper-track/analyses/[paper-title-slug].md`.

## Error Handling

- If the paper cannot be found: report clearly, suggest alternative search terms
- If the paper is behind a paywall: analyze based on available abstract, blog posts, and summaries; note that analysis is based on limited access
- If the paper is very recent with no external discussion: note this and focus on the abstract and any available content
