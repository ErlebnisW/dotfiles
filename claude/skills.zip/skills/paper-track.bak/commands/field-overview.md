---
description: Generate a macro-level overview of a research field based on recent papers
argument-hint: "[topic] [--days N]"
allowed-tools: Task, WebSearch, WebFetch, Read, Write
---

# Field Overview

Generate a macro-level overview and landscape analysis for a research field.

## Topic

$ARGUMENTS

## Argument Parsing

- **topic** (required): The research field or area to analyze
- **--days N** (default: 30): Time window in days (default is 30 for field overviews to capture broader trends)
- **--lang en|zh** (default: en): Output language

## Workflow

### Step 1: Broad Paper Collection

Search broadly to capture the landscape. Deploy parallel searches:

```
WebSearch: [topic] survey paper [current year]
WebSearch: [topic] recent advances [current year]
WebSearch: site:arxiv.org [topic] [current year]
WebSearch: [topic] benchmark state-of-the-art [current year]
WebSearch: [topic] research trends [current year]
```

Also search for:
- Survey/review papers on the topic (these provide excellent landscape context)
- Workshop/tutorial pages from recent conferences (NeurIPS, ICML, ICLR, ACL, CVPR)
- Blog posts from major labs (Google DeepMind, OpenAI, Meta AI, Anthropic, Microsoft Research)

Collect 20-50 papers/resources for landscape analysis.

### Step 2: Cluster and Categorize

Group the collected papers into 3-7 thematic clusters:
- Identify recurring themes, methods, and problem formulations
- Note which clusters are growing vs. shrinking in activity
- Identify cross-cutting themes that span multiple clusters

### Step 3: Field Synthesis

Apply the **field-synthesizer** sub-skill framework:

#### Section 1: Field Overview
What is this research area about? Provide 2-3 paragraphs of context suitable for a researcher adjacent to (but not deeply in) this field.

#### Section 2: Active Research Directions
List 3-7 major directions. For each:
- What the direction is about (1-2 sentences)
- Key papers and groups driving it (with links)
- Current state of progress (early/active/maturing)
- Open challenges within this direction

#### Section 3: Methodological Trends
- What techniques/approaches are gaining traction?
- What is falling out of favor and why?
- Any paradigm shifts underway?
- Common evaluation benchmarks and datasets

#### Section 4: Key Players & Groups
- Most active research labs (academic and industry)
- Prolific individual researchers
- Notable collaborations or research programs
- Emerging groups to watch

#### Section 5: Research Gaps
- Important problems that are NOT being addressed
- Where is the field collectively blind?
- Under-explored combinations of existing techniques
- Missing benchmarks or evaluation criteria

#### Section 6: Opportunities & White Spaces
For each identified opportunity:
- **Description**: What the opportunity is
- **Potential Impact**: High / Medium / Low
- **Competition Level**: High / Medium / Low
- **Feasibility for a PhD student**: High / Medium / Low
- **Why now**: What makes this timely

#### Section 7: Predictions
Where is this field heading in 6-12 months? Be specific and actionable:
- Which directions will likely see breakthroughs?
- Which problems might get solved?
- What new problems will emerge?
- Which conferences will feature this work prominently?

### Step 4: Output

Save to `RESEARCH/paper-track/[topic-slug]/field_overview.md`.

If `--lang zh` is specified, write all content in Chinese with bilingual technical terms.

## Quality Checklist

Before finalizing, verify:
- [ ] At least 3 distinct research directions identified
- [ ] Each direction has at least 2 specific paper references
- [ ] Gaps and opportunities are specific and actionable (not generic)
- [ ] Predictions are concrete and time-bounded
- [ ] Key players section covers both academia and industry
- [ ] The overview would genuinely help a PhD student orient themselves

Begin the field overview analysis now.
