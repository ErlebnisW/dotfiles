# Paper Searcher - Instructions

## Search Strategy Per Source

### 1. arXiv Search

arXiv is the primary source for AI/ML preprints. Use these search patterns:

**WebSearch queries:**
```
site:arxiv.org [topic keywords] [current year]
site:arxiv.org abs [topic keywords]
arxiv [topic] submitted [month] [year]
```

**WebSearch with domain filtering:**
```python
WebSearch(query="[topic keywords] [year]", allowed_domains=["arxiv.org"])
```

**Tips:**
- arXiv papers have IDs like `2401.12345`. The first 4 digits encode year+month.
- Use specific technical terms rather than broad categories
- For sub-fields, add category prefixes: "cs.CL" (NLP), "cs.CV" (vision), "cs.LG" (ML), "cs.AI" (AI)
- Search for both the topic AND related benchmark/dataset names

**Metadata extraction via WebFetch:**
Fetch the arXiv abstract page (`arxiv.org/abs/XXXX.XXXXX`) to extract:
- Title (in the `<h1>` tag)
- Authors (in the author list)
- Abstract (in the `<blockquote>` section)
- Submission date
- Categories

### 2. Semantic Scholar Search

Semantic Scholar provides rich citation data and paper metadata.

**WebSearch queries:**
```
site:semanticscholar.org [topic keywords] [current year]
semanticscholar.org [topic] [year]
```

**Tips:**
- Semantic Scholar is best for getting citation counts and influence metrics
- Look for the "Highly Influential Citations" count
- Cross-reference arXiv papers here for citation data
- The URL format is: `semanticscholar.org/paper/[title-slug]/[hash]`

### 3. Google Scholar Search

Google Scholar has the broadest academic coverage.

**WebSearch queries:**
```
[topic keywords] research paper [current year]
[topic keywords] conference paper [year] NeurIPS OR ICML OR ICLR OR ACL OR CVPR
"[exact topic phrase]" [year] filetype:pdf
```

**Tips:**
- Google Scholar includes published versions, not just preprints
- Use quotes for exact phrase matching
- Add venue names to find peer-reviewed versions
- Results often include citations counts in snippets

### 4. Papers With Code Search

Papers With Code links papers to their implementations.

**WebSearch queries:**
```
site:paperswithcode.com [topic keywords]
paperswithcode.com methods [topic]
paperswithcode.com sota [topic benchmark]
```

**Tips:**
- Great for finding papers with available code
- Check the "trending" and "latest" sections
- Look for benchmark leaderboard entries
- Papers here often have reproducible results

### 5. HuggingFace Papers Search

HuggingFace curates trending ML papers daily.

**WebSearch queries:**
```
site:huggingface.co/papers [topic keywords]
huggingface.co papers [topic] [year]
```

**Tips:**
- HuggingFace papers page shows community-upvoted papers
- Good for finding papers with models/datasets on the Hub
- Check the daily papers page for very recent work

## Deduplication Strategy

After collecting results from all sources, deduplicate:

1. **By arXiv ID**: If two results share the same arXiv ID (e.g., `2401.12345`), keep the one with the most metadata
2. **By DOI**: If two results share the same DOI, merge their metadata
3. **By title similarity**: If two titles match >90% (case-insensitive, ignoring punctuation), treat as duplicates
   - Keep the version with the most complete metadata
   - Merge citation counts (take the higher number)
   - Note all source URLs

## Time Window Filtering

Calculate the cutoff date: `cutoff = today - N days`

For each paper:
- Extract the publication/submission date
- If the date is before the cutoff, exclude it
- If the date cannot be determined, include it but flag as "date uncertain"
- For arXiv papers, use the submission date (v1), not the latest revision date

## Output Format

Return a structured list sorted by date (newest first):

```markdown
## Search Results: [topic] (last N days)

**Sources searched:** arXiv, Semantic Scholar, Google Scholar, Papers With Code, HuggingFace
**Time window:** [start date] to [end date]
**Total papers found:** X (after deduplication)

### Papers

1. **[Title]**
   - Authors: [First Author] et al.
   - Date: YYYY-MM-DD
   - Abstract: [First 2-3 sentences]
   - URL: [canonical link]
   - Citations: [count or N/A]
   - Found on: [source1, source2]

2. **[Title]**
   ...
```

## Error Handling

- If a source returns no results, note it and continue with other sources
- If WebFetch fails on a paper URL, use whatever metadata is available from the search results
- If fewer than 3 papers are found, suggest broadening the topic or extending the time window
- Always report which sources were searched and which returned results
