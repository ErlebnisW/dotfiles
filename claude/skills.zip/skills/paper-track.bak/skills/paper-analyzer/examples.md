# Paper Analyzer - Examples

## Example: Full Analysis of a Paper

### Paper: "Scaling LLM Test-Time Compute Optimally Can Be More Effective Than Scaling Model Parameters"

*(Note: This is an illustrative example. Details are representative of the analysis format.)*

---

### Must-Read Rationale

This paper is essential reading for anyone working on LLM inference or reasoning because it provides the first rigorous framework for optimally allocating test-time compute. It demonstrates that a smaller model with optimal test-time compute allocation can outperform a 14x larger model, fundamentally challenging the assumption that model scale is the primary path to better performance. Reading it will reshape how you think about the cost-performance tradeoff in LLM deployment.

### Core Insight

The key insight is that test-time compute scaling follows a predictable, optimizable curve -- and the optimal strategy depends on the difficulty of the query. For easy questions, a single model call suffices; for hard questions, allocating compute to search against a process reward model yields dramatically better results than simply using a larger model. This means inference-time compute is not just a substitute for model size but can be *more efficient* than parameter scaling.

### Technical Approach

**Problem Formulation:**
Given a fixed inference compute budget B and a query q, what is the optimal strategy to maximize the probability of a correct answer? The paper formalizes this as a resource allocation problem across two dimensions: (1) how many candidate responses to generate, and (2) how to use a verifier to select among them.

**Proposed Method:**
The authors study two families of test-time compute strategies:
1. **Best-of-N sampling**: Generate N independent responses, score each with a reward model, return the best
2. **Tree search with process reward model (PRM)**: Use beam search or MCTS guided by a step-level reward model to construct solutions incrementally

They characterize the compute-optimal frontier by measuring performance as a function of total FLOPs spent at inference time, sweeping across strategies and their hyperparameters.

**Key Innovations vs Prior Work:**
- First to formally characterize the compute-optimal frontier for test-time scaling (analogous to Chinchilla scaling laws but for inference)
- Introduces a difficulty-adaptive allocation strategy: easy questions get minimal compute, hard questions get search-heavy compute
- Shows that process reward models (step-level verification) are strictly more compute-efficient than outcome reward models (answer-level verification)

### Hardest Problem & Solution

The hardest problem was making tree search with process reward models efficient enough to be practical. Naive MCTS over token sequences has an astronomical branching factor and most branches are wasted. The authors solved this by operating at the *reasoning step* granularity rather than token level -- the PRM scores complete reasoning steps, and search branches at step boundaries only. This reduces the effective branching factor from ~50,000 (vocabulary size) to ~5-10 (candidate next steps), making tree search tractable while preserving the benefit of step-level guidance.

### Key Results

- **Main result**: A Llama-8B model with optimal test-time compute allocation matches or exceeds the performance of a Llama-70B model (14x larger) on MATH benchmark, while using roughly equivalent total FLOPs
- **Scaling curve**: Test-time compute shows log-linear improvement up to ~256x base compute, then diminishing returns
- **Strategy comparison**: PRM-guided tree search is 4-8x more compute-efficient than best-of-N sampling across all difficulty levels
- **Difficulty adaptation**: The optimal compute allocation varies by 100x between easy and hard questions; uniform allocation wastes 40% of compute
- **Surprising finding**: On the easiest 20% of problems, allocating ANY additional test-time compute beyond a single forward pass actually hurts performance (due to reward model false positives)

### Limitations & Open Questions

- **PRM dependency**: The approach requires a high-quality process reward model, which is expensive to train and may not exist for all domains
- **Domain specificity**: Evaluated primarily on math reasoning; unclear how well the scaling curves transfer to creative writing, coding, or open-ended tasks
- **PRM ceiling**: As the base model improves, the PRM may become the bottleneck; no analysis of when PRM quality limits the approach
- **Latency**: Tree search inherently increases latency; no analysis of latency-constrained settings
- **Training-inference tradeoff**: The total compute (training + inference) comparison with larger models is not fully explored

### Connections

- **Builds on**: Process reward models (Lightman et al., 2023), self-consistency / majority voting (Wang et al., 2023), Chinchilla scaling laws (Hoffmann et al., 2022)
- **Related concurrent work**: "Large Language Monkeys" (Brown et al., 2024) which studies coverage scaling; "Let's Verify Step by Step" which provides PRM training data
- **Enables**: Inference-time compute markets, adaptive compute allocation systems, cost-optimized LLM serving that routes easy vs. hard queries differently
- **Contrasts with**: "Scaling Data-Constrained Language Models" which argues for data scaling; this paper provides an orthogonal scaling axis

### One-Line Summary

Optimally allocating test-time compute via PRM-guided search lets a small LLM match a 14x larger model, establishing inference-time scaling as a viable alternative to parameter scaling.

---

## Output File Format

When saved to disk, the analysis is written as:

```
RESEARCH/paper-track/[topic-slug]/papers/01-scaling-llm-test-time-compute.md
```

With the content structured exactly as the sections above, prefixed with a YAML-style header:

```markdown
# Scaling LLM Test-Time Compute Optimally Can Be More Effective Than Scaling Model Parameters

**Authors:** Snell, C. et al.
**Date:** 2026-01-XX
**URL:** https://arxiv.org/abs/XXXX.XXXXX
**Venue:** arXiv preprint
**Selection Score:** 84/100

---

[Analysis sections follow...]
```
