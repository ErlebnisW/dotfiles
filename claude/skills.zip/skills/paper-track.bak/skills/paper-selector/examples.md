# Paper Selector - Examples

## Example: Selecting Top 3 Papers on "Efficient LLM Inference"

### Candidate Papers (6 papers from search)

1. "FlashDecoding++: Faster Large Language Model Inference on GPUs" - Li et al., 2026
2. "Speculative Decoding with Big Little Decoder Revisited" - Kim et al., 2026
3. "MoE-Infinity: Offloading-Aware Mixture of Experts Inference" - Xue et al., 2026
4. "A Survey of Efficient LLM Inference" - Zhang et al., 2026
5. "KV-Cache Compression via Learned Token Merging" - Wang et al., 2026
6. "Quantizing Large Language Models to 2 Bits Without Quality Loss" - Park et al., 2026

### Scoring

#### Paper 1: FlashDecoding++
| Criterion | Score | Reasoning |
|-----------|-------|-----------|
| Novelty | 7/10 | Builds on FlashAttention/FlashDecoding but introduces new warp-level optimizations |
| Impact | 8/10 | Direct practical impact; will be widely adopted if open-sourced |
| Rigor | 8/10 | Benchmarks on 5 model families, comparison with 4 baselines, detailed ablations |
| Relevance | 10/10 | Exactly on topic: GPU kernel optimization for LLM inference |
| Momentum | 7/10 | 15 citations in 2 weeks; discussed on HuggingFace and Twitter |
| Venue | 2/5 | arXiv preprint from a known systems lab |
**Composite: (7/10*20) + (8/10*20) + (8/10*15) + (10/10*25) + (7/10*10) + (2/5*10) = 14 + 16 + 12 + 25 + 7 + 4 = 78/100**

#### Paper 2: Speculative Decoding Revisited
| Criterion | Score | Reasoning |
|-----------|-------|-----------|
| Novelty | 5/10 | Revisits existing technique with incremental improvements |
| Impact | 6/10 | Useful but speculative decoding is well-studied |
| Rigor | 7/10 | Good baselines but limited model diversity |
| Relevance | 9/10 | Directly relevant to efficient inference |
| Momentum | 4/10 | 3 citations; limited social media attention |
| Venue | 1/5 | arXiv preprint, authors less established |
**Composite: (5/10*20) + (6/10*20) + (7/10*15) + (9/10*25) + (4/10*10) + (1/5*10) = 10 + 12 + 10.5 + 22.5 + 4 + 2 = 61/100**

#### Paper 3: MoE-Infinity
| Criterion | Score | Reasoning |
|-----------|-------|-----------|
| Novelty | 8/10 | First offloading-aware MoE system; new problem formulation |
| Impact | 7/10 | Enables running huge MoE models on consumer hardware |
| Rigor | 7/10 | Tested on 3 MoE models but limited scale experiments |
| Relevance | 8/10 | Relevant to inference efficiency, specifically MoE models |
| Momentum | 6/10 | 8 citations; trending on Papers With Code |
| Venue | 3/5 | Accepted at a top systems conference |
**Composite: (8/10*20) + (7/10*20) + (7/10*15) + (8/10*25) + (6/10*10) + (3/5*10) = 16 + 14 + 10.5 + 20 + 6 + 6 = 72.5/100**

#### Paper 4: Survey of Efficient LLM Inference
| Criterion | Score | Reasoning |
|-----------|-------|-----------|
| Novelty | 3/10 | Survey, not novel research |
| Impact | 6/10 | Useful reference but surveys rarely drive new work |
| Rigor | 6/10 | Comprehensive coverage but no new experiments |
| Relevance | 10/10 | Directly on topic |
| Momentum | 5/10 | Moderate citations for a survey |
| Venue | 2/5 | arXiv preprint |
**Composite: (3/10*20) + (6/10*20) + (6/10*15) + (10/10*25) + (5/10*10) + (2/5*10) = 6 + 12 + 9 + 25 + 5 + 4 = 61/100**

#### Paper 5: KV-Cache Compression
| Criterion | Score | Reasoning |
|-----------|-------|-----------|
| Novelty | 8/10 | Novel learned token merging approach for KV-cache |
| Impact | 8/10 | KV-cache is a major bottleneck; widely applicable |
| Rigor | 9/10 | Extensive experiments, 6 models, ablations, memory profiling |
| Relevance | 9/10 | Directly addresses inference memory efficiency |
| Momentum | 8/10 | 22 citations in first week; HuggingFace daily paper |
| Venue | 4/5 | Accepted at ICML 2026 |
**Composite: (8/10*20) + (8/10*20) + (9/10*15) + (9/10*25) + (8/10*10) + (4/5*10) = 16 + 16 + 13.5 + 22.5 + 8 + 8 = 84/100**

#### Paper 6: 2-Bit Quantization
| Criterion | Score | Reasoning |
|-----------|-------|-----------|
| Novelty | 7/10 | Pushes quantization to 2-bit without quality degradation; non-trivial |
| Impact | 7/10 | Practical for deployment but quantization is competitive space |
| Rigor | 8/10 | Tested across 4 model families with perplexity and downstream tasks |
| Relevance | 8/10 | Relevant to efficient inference via model compression |
| Momentum | 6/10 | 10 citations; code released on GitHub |
| Venue | 3/5 | Workshop paper at NeurIPS |
**Composite: (7/10*20) + (7/10*20) + (8/10*15) + (8/10*25) + (6/10*10) + (3/5*10) = 14 + 14 + 12 + 20 + 6 + 6 = 72/100**

### Final Selection: Top 3

```markdown
## Paper Selection: Top 3 for "Efficient LLM Inference"

### #1: KV-Cache Compression via Learned Token Merging (Score: 84/100)
**Scores:** Novelty: 8/10 | Impact: 8/10 | Rigor: 9/10 | Relevance: 9/10 | Momentum: 8/10 | Venue: 4/5
**Rationale:** Selected as the top paper for its novel learned token merging approach to KV-cache compression, which addresses the critical memory bottleneck in long-context inference. Accepted at ICML 2026 with exceptional early citation velocity.

### #2: FlashDecoding++ (Score: 78/100)
**Scores:** Novelty: 7/10 | Impact: 8/10 | Rigor: 8/10 | Relevance: 10/10 | Momentum: 7/10 | Venue: 2/5
**Rationale:** Selected for its direct practical impact on GPU inference speed through novel warp-level kernel optimizations, building on the highly influential FlashAttention line of work.

### #3: MoE-Infinity (Score: 72.5/100)
**Scores:** Novelty: 8/10 | Impact: 7/10 | Rigor: 7/10 | Relevance: 8/10 | Momentum: 6/10 | Venue: 3/5
**Rationale:** Selected for opening a new problem space (offloading-aware MoE inference) that enables running massive mixture-of-experts models on consumer hardware, expanding access to frontier model architectures.
```
