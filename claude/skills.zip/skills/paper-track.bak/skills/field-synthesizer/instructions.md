# Field Synthesizer - Instructions

## Synthesis Protocol

Analyze a collection of recent papers to produce a macro-level overview of a research field. The synthesis should help PhD researchers orient themselves, identify opportunities, and make strategic decisions.

### Information Sources

Beyond the collected papers, also gather context from:
- Recent survey papers on the topic
- Conference workshop/tutorial pages (NeurIPS, ICML, ICLR, ACL, CVPR)
- Blog posts from major labs (Google DeepMind, OpenAI, Meta AI, Anthropic, Microsoft Research)
- Research job postings (indicate what labs are investing in)
- Benchmark leaderboards (indicate active competition areas)

### Section 1: Field Overview

**Purpose:** Provide context for a researcher adjacent to but not deeply in this field.

**Guidelines:**
- Write 2-3 paragraphs covering:
  - What is this research area fundamentally about?
  - Why does it matter? What problems does it solve?
  - What is the current state of maturity? (nascent / rapidly growing / maturing / saturated)
- Use accessible language; avoid assuming deep domain knowledge
- Mention the key enabling breakthroughs that made current work possible

### Section 2: Active Research Directions

**Purpose:** Map the landscape of current work into coherent themes.

**Guidelines:**
- Identify 3-7 major research directions
- For each direction provide:
  - **Name**: A descriptive label (e.g., "Efficient Fine-Tuning Methods")
  - **Description**: 1-2 sentences on what this direction is about
  - **Key Papers**: 2-4 representative papers with links
  - **Key Groups**: Which labs/researchers are driving this direction
  - **Status**: Early-stage / Actively growing / Maturing / Consolidating
  - **Open Challenges**: 1-2 unsolved problems within this direction

**Clustering strategy:**
- Start by listing all papers and their primary contributions
- Group papers that address similar problems or use similar techniques
- Merge clusters that are too small (< 2 papers)
- Split clusters that are too broad (> 10 papers)
- Name each cluster with a descriptive, non-overlapping label

### Section 3: Methodological Trends

**Purpose:** Identify which techniques are rising and falling in popularity.

**Guidelines:**
- **Rising techniques**: Methods appearing frequently in recent papers
  - Why they are gaining traction
  - What advantage they offer over older approaches
  - Example papers that exemplify this trend

- **Declining techniques**: Methods that were popular but are being replaced
  - Why they are falling out of favor
  - What is replacing them

- **Paradigm shifts**: Any fundamental changes in how the field approaches problems
  - What changed and why
  - Is this shift complete or still in progress?

- **Common evaluation practices**: Standard benchmarks, datasets, and metrics
  - Which benchmarks are considered gold standard?
  - Are any benchmarks becoming saturated or obsolete?
  - Any new benchmarks gaining adoption?

### Section 4: Key Players & Groups

**Purpose:** Identify who is doing the most impactful work.

**Guidelines:**

**Academic Labs:**
- List 5-10 most active academic groups
- Note their university, PI name, and primary focus area
- Mention recent notable papers from each

**Industry Labs:**
- List 3-7 most active industry labs
- Note their parent company and research focus
- Mention any unique advantages (data, compute, deployment scale)

**Individual Researchers:**
- Identify 5-10 prolific or rising researchers
- Note their affiliation and contribution area
- Highlight any emerging researchers (early career with high impact)

**Collaborations:**
- Notable academic-industry partnerships
- Cross-institutional research programs
- Shared benchmarks or datasets

### Section 5: Research Gaps

**Purpose:** Identify important problems that are NOT being adequately addressed.

**Guidelines:**
- Be specific and actionable; vague gaps are useless
- For each gap, explain:
  - What the gap is
  - Why it matters (what would solving it enable?)
  - Why it might be under-explored (too hard? not trendy? overlooked?)
  - Any partial attempts that fell short

**Categories of gaps to consider:**
- **Missing evaluations**: Important use cases or domains not covered
- **Scalability gaps**: Methods that work small but not large (or vice versa)
- **Theory gaps**: Empirical results without theoretical understanding
- **Fairness/safety gaps**: Social impact considerations being ignored
- **Integration gaps**: Components that work individually but not together
- **Real-world gaps**: Lab results that do not translate to deployment

### Section 6: Opportunities & White Spaces

**Purpose:** Identify the most promising directions for new research.

**Guidelines:**
For each opportunity:

```markdown
#### Opportunity: [Descriptive Name]

**Description:** [What the opportunity is, in 2-3 sentences]

**Potential Impact:** High / Medium / Low
[Brief justification]

**Competition Level:** High / Medium / Low
[How many groups are working on this? Is there a first-mover advantage?]

**Feasibility for a PhD Student:** High / Medium / Low
[Does this require massive compute? Proprietary data? Large team?]

**Why Now:** [What makes this timely? New datasets? New techniques? New demand?]

**Possible Approaches:** [1-2 suggested starting points]
```

**Prioritize opportunities that are:**
- High impact + Low competition + High feasibility = Best for PhD students
- Enabled by very recent work (last 3-6 months)
- At the intersection of two active directions (cross-pollination)

### Section 7: Predictions

**Purpose:** Forecast where the field is heading in 6-12 months.

**Guidelines:**
- Be specific and time-bounded
- Base predictions on observable trends, not wishful thinking
- Include both optimistic and cautious scenarios
- Structure predictions as:

```markdown
1. **[Prediction]** (Confidence: High/Medium/Low)
   [1-2 sentences of reasoning]
   Timeline: [X months]
```

**Types of predictions:**
- Which research directions will accelerate?
- Which problems are close to being solved?
- What new problems will emerge?
- Which benchmarks will be superseded?
- Which conferences will feature this work prominently?
- Will there be a paradigm shift or consolidation?

## Language Handling

If `--lang zh` is specified:
- Write all synthesis content in Chinese
- Keep proper nouns (lab names, researcher names, paper titles) in English
- Bilingual technical terms: "强化学习 (Reinforcement Learning)"
- Maintain the same structure and depth

## Quality Checklist

Before delivering:
- [ ] At least 3 distinct research directions identified
- [ ] Each direction references at least 2 specific papers
- [ ] Gaps are specific and actionable (not "more work is needed")
- [ ] Opportunities are rated on all 3 dimensions (impact, competition, feasibility)
- [ ] Predictions are time-bounded and based on evidence
- [ ] Key players section covers both academia AND industry
- [ ] Rising AND declining methodological trends are identified
- [ ] The overview would genuinely help a PhD student orient themselves in 30 minutes
